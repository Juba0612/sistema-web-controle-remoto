<?php
/** Configuração da Conexão com o Banco de Dado (PDO), 
 * este código define credenciais e inicializa a variável global para ser usada em todos os Models */

$host = 'localhost';
$db_name = 'ltr_control';
$username = 'root';
$password = '';

try {
    // Inicializa a conexão
    $pdo = new PDO("mysql:host=$host;dbname=$db_name;charset=utf8", $username, $password);
    
    // Em caso de erros, força o PDO a lançar exceções
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

} catch (PDOException $e) {
    // Interrompe a execução se a conexão com o banco falhar e exiibe a mensagem
    die("Erro na conexão com o banco de dados: " . $e->getMessage());
}