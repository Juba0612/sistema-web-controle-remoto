<?php
// Controlador que serve para gerenciar todas as ações de usuários e autenticação.
// Trata login, logout, dashboard, gerenciamento de CRUD de usuários, proteção de rotas, segurança (CSRF, Rate Limiting) e logs.

require_once __DIR__ . '/../models/UsuarioModel.php';
require_once __DIR__ . '/../models/LogModel.php';

class UsuarioController {

    // Exibe o formulário de login, pode exibir mensagens de erro de tentativas anteriores.
    
    public function mostrarLogin() {
        if (isset($_SESSION['erro_login'])) {
            $erro_login = $_SESSION['erro_login'];
            unset($_SESSION['erro_login']); // Limpa o erro da sessão
        }
        
        require __DIR__ . '/../views/login.php';
    }

    // Implementa proteção contra Força Bruta (Rate Limiting) e CSRF
    // em caso de sucesso, regenera a sessão e armazena os dados do usuário
    // em caso de falha, registra o log e a tentativa.
     
    public function autenticar() {
        global $pdo;

        // Rate Limiting (Força Bruta)
        // Verifica se o usuário já está bloqueado
        if (isset($_SESSION['login_bloqueado_ate']) && $_SESSION['login_bloqueado_ate'] > time()) {
            $tempo_restante = ceil(($_SESSION['login_bloqueado_ate'] - time()) / 60);
            $_SESSION['erro_login'] = "Muitas tentativas falhas. Tente novamente em $tempo_restante minuto(s).";
            header('Location: index.php?acao=login');
            exit;
        }
        // Limpa o bloqueio se o tempo já passou
        if (isset($_SESSION['login_bloqueado_ate']) && $_SESSION['login_bloqueado_ate'] <= time()) {
            unset($_SESSION['login_bloqueado_ate']);
            unset($_SESSION['tentativas_login']);
        }

        // Validação de Token CSRF
        if ($_SERVER['REQUEST_METHOD'] !== 'POST' || !isset($_POST['csrf_token']) || !hash_equals($_SESSION['csrf_token'], $_POST['csrf_token'])) {
            $_SESSION['erro_login'] = "Erro de segurança (CSRF).";
            header('Location: index.php?acao=login');
            exit;
        }

        // Validação e sanitização de entrada
        $email = filter_input(INPUT_POST, 'email', FILTER_SANITIZE_EMAIL);
        $senha = $_POST['senha'] ?? '';

        if (empty($email) || empty($senha)) {
            $_SESSION['erro_login'] = "Email e senha são obrigatórios.";
            header('Location: index.php?acao=login');
            exit;
        }

        $usuarioModel = new UsuarioModel($pdo);
        $usuario = $usuarioModel->verificarCredenciais($email, $senha);

      
        if ($usuario) {
            // Se for sucesso no login
            
            // Limpa o rastreador de tentativas de força bruta
            unset($_SESSION['tentativas_login']);
            unset($_SESSION['login_bloqueado_ate']);

            // Armazena dados na sessão
            session_regenerate_id(true); 
            $_SESSION['usuario_id'] = $usuario['id'];
            $_SESSION['usuario_nome'] = $usuario['name'];      // Era 'nome'
            $_SESSION['usuario_perfil'] = $usuario['user_type'];
            $_SESSION['csrf_token'] = bin2hex(random_bytes(32)); 

            header('Location: index.php?acao=dashboard');
            exit;

        } else {
            // Se não fizer o login
            
            // Registra a tentativa falha no log
            $logModel = new LogModel($pdo);
            $logModel->registrar(null, "Tentativa de login falhada para o email: '$email'");

            // Gera o contador de tentativas de força bruta
            if (!isset($_SESSION['tentativas_login'])) {
                $_SESSION['tentativas_login'] = 0;
            }
            $_SESSION['tentativas_login']++;

            $tentativas_restantes = 5 - $_SESSION['tentativas_login'];

            // Se atingir o limite é bloqueado
            if ($_SESSION['tentativas_login'] >= 5) {
                $_SESSION['login_bloqueado_ate'] = time() + (5 * 60); // Bloqueio de 5 minutos
                unset($_SESSION['tentativas_login']); 
                $_SESSION['erro_login'] = "Muitas tentativas falhas. Tente novamente em 5 minuto(s).";
            } else {
                $_SESSION['erro_login'] = "Email ou senha inválidos. ($tentativas_restantes tentativas restantes)";
            }
            
            header('Location: index.php?acao=login');
            exit;
        }
    }

    // Depois do login, exibe o painel de controle principal, exigindo que o usuário esteja logado
     
    public function dashboard() {
        // Proteção de rota
        if (!isset($_SESSION['usuario_id'])) {
            header('Location: index.php?acao=login');
            exit;
        }
        
        require __DIR__ . '/../views/dashboard.php';
    }

    // Logout
    public function logout() {
        session_destroy();
        header('Location: index.php?acao=home');
        exit;
    }

    // Verifica se o usuário é Administrador
    // se não for, redireciona para o login com erro
    private function verificarAdmin() {
        if (!isset($_SESSION['usuario_id']) || $_SESSION['usuario_perfil'] != 'admin') {
            $_SESSION['erro_login'] = "Acesso negado. Você precisa ser administrador.";
            header('Location: index.php?acao=login');
            exit;
        }
    }

    // Para os admins exibe a página de gerenciamento de usuários (tabela).
    public function gerenciarUsuarios() {
        global $pdo;
        $this->verificarAdmin(); // Exige que seja Admin

        if (isset($_SESSION['mensagem_sucesso'])) {
            $mensagem_sucesso = $_SESSION['mensagem_sucesso'];
            unset($_SESSION['mensagem_sucesso']);
        }

        $usuarioModel = new UsuarioModel($pdo);
        $usuarios = $usuarioModel->buscarTodosUsuarios();

        require __DIR__ . '/../views/usuarios_gerenciar.php';
    }

    // Exibe o formulário para Criar ou Editar um usuário
    public function mostrarFormularioUsuario() {
        global $pdo;
        $this->verificarAdmin(); // Eexige Admin

        $usuario = null;
        $id_usuario = filter_input(INPUT_GET, 'id', FILTER_VALIDATE_INT);

        if ($id_usuario) {
   
            $usuarioModel = new UsuarioModel($pdo);
            $usuario = $usuarioModel->buscarUsuarioPorId($id_usuario);

            if (!$usuario) {
                $_SESSION['mensagem_sucesso'] = "Erro: Usuário não encontrado.";
                header('Location: index.php?acao=gerenciar_usuarios');
                exit;
            }
        }

        if (isset($_SESSION['erro_validacao'])) {
            $erro_validacao = $_SESSION['erro_validacao'];
            unset($_SESSION['erro_validacao']);
        }

        require __DIR__ . '/../views/usuario_form.php';
    }

    // Valida, sanitiza, salva, e registra o log.

    public function salvarUsuario() {
        global $pdo;
        $this->verificarAdmin(); // Exige Admin

        // Validação de Token CSRF
        if ($_SERVER['REQUEST_METHOD'] !== 'POST' || !isset($_POST['csrf_token']) || !hash_equals($_SESSION['csrf_token'], $_POST['csrf_token'])) {
            $_SESSION['erro_validacao'] = "Erro de segurança (CSRF).";
            header('Location: index.php?acao=criar_usuario_form');
            exit;
        }

        // Validação e sanitização de entrada (Proteção XSS)
        $nome = filter_input(INPUT_POST, 'nome', FILTER_SANITIZE_STRING);
        $email = filter_input(INPUT_POST, 'email', FILTER_SANITIZE_EMAIL);
        $perfil = $_POST['perfil'] ?? '';
        $senha = $_POST['senha'] ?? '';

        if (empty($nome) || empty($email) || empty($perfil) || empty($senha)) {
            $_SESSION['erro_validacao'] = "Todos os campos são obrigatórios.";
            header('Location: index.php?acao=criar_usuario_form');
            exit;
        }

if ($perfil != 'admin' && $perfil != 'standart') {
            $_SESSION['erro_validacao'] = "Perfil inválido.";
            header('Location: index.php?acao=criar_usuario_form');
            exit;
        }

        $usuarioModel = new UsuarioModel($pdo);
        $sucesso = $usuarioModel->criarUsuario($nome, $email, $perfil, $senha);

        if ($sucesso) {
            // Registra a ação no log
            $logModel = new LogModel($pdo); 
            $logModel->registrar($_SESSION['usuario_id'], "Criou o usuário: '$nome' ($email)");
            
            $_SESSION['mensagem_sucesso'] = "Usuário criado com sucesso!";
            header('Location: index.php?acao=gerenciar_usuarios');
            exit;
        } else {
            $_SESSION['erro_validacao'] = "Erro ao criar usuário (Email talvez já exista).";
            header('Location: index.php?acao=criar_usuario_form');
            exit;
        }
    }

    // Valida, sanitiza, atualiza, e registra o log.
 
    public function atualizarUsuario() {
        global $pdo;
        $this->verificarAdmin(); // Exige Admin

        // Validação de Token CSRF
        if ($_SERVER['REQUEST_METHOD'] !== 'POST' || !isset($_POST['csrf_token']) || !hash_equals($_SESSION['csrf_token'], $_POST['csrf_token'])) {
            $_SESSION['erro_validacao'] = "Erro de segurança (CSRF).";
            header('Location: index.php?acao=gerenciar_usuarios');
            exit;
        }

        // Validação e sanitização
        $id_usuario = filter_input(INPUT_POST, 'id_usuario', FILTER_VALIDATE_INT);
        $nome = filter_input(INPUT_POST, 'nome', FILTER_SANITIZE_STRING);
        $email = filter_input(INPUT_POST, 'email', FILTER_SANITIZE_EMAIL);
        $perfil = $_POST['perfil'] ?? '';
        $nova_senha = $_POST['senha'] ?? '';

        if (empty($id_usuario) || empty($nome) || empty($email) || empty($perfil)) {
            $_SESSION['erro_validacao'] = "Todos os campos (exceto senha) são obrigatórios.";
            header('Location: index.php?acao=editar_usuario_form&id=' . $id_usuario);
            exit;
        }

        if ($perfil != 'admin' && $perfil != 'standart') {
            $_SESSION['erro_validacao'] = "Perfil inválido.";
            header('Location: index.php?acao=editar_usuario_form&id=' . $id_usuario);
            exit;
        }

        // Atualiza dados
        $usuarioModel = new UsuarioModel($pdo);
        $sucesso = $usuarioModel->atualizarUsuario($id_usuario, $nome, $email, $perfil);

        if (!$sucesso) {
            $_SESSION['erro_validacao'] = "Erro ao atualizar usuário (Email talvez já exista).";
            header('Location: index.php?acao=editar_usuario_form&id=' . $id_usuario);
            exit;
        }

        // Atualiza a senha apenas se uma nova foi inserida
        if (!empty($nova_senha)) {
            $usuarioModel->atualizarSenha($id_usuario, $nova_senha);
        }

        $_SESSION['mensagem_sucesso'] = "Usuário atualizado com sucesso!";

        // Registra a ação no log
        $logModel = new LogModel($pdo); 
        $logModel->registrar($_SESSION['usuario_id'], "Atualizou o usuário ID: $id_usuario ('$nome')");
        
        header('Location: index.php?acao=gerenciar_usuarios');
        exit;
    }

    // Valida CSRF, ID, e previne auto-exclusão.
    public function excluirUsuario() {
        global $pdo;
        $this->verificarAdmin(); //Exige Admin

        // Validação de Token CSRF
        if ($_SERVER['REQUEST_METHOD'] !== 'POST' || 
            !isset($_POST['csrf_token']) || 
            !hash_equals($_SESSION['csrf_token'], $_POST['csrf_token'])) {
            
            $_SESSION['mensagem_sucesso'] = "Erro de segurança (CSRF). Ação cancelada.";
            header('Location: index.php?acao=gerenciar_usuarios');
            exit;
        }

        $id_usuario = filter_input(INPUT_POST, 'id', FILTER_VALIDATE_INT);

        // Impede que o admin se auto-exclua
        if ($id_usuario == $_SESSION['usuario_id']) {
            $_SESSION['mensagem_sucesso'] = "Erro: Você não pode excluir sua própria conta!";
            header('Location: index.php?acao=gerenciar_usuarios');
            exit;
        }

        if (empty($id_usuario)) {
            $_SESSION['mensagem_sucesso'] = "Erro: ID de usuário inválido.";
            header('Location: index.php?acao=gerenciar_usuarios');
            exit;
        }

        $usuarioModel = new UsuarioModel($pdo);
        $usuarioModel->excluirUsuario($id_usuario);

        // Registra a ação no log
        $logModel = new LogModel($pdo);
        $logModel->registrar($_SESSION['usuario_id'], "Excluiu o usuário ID: $id_usuario");
        
        $_SESSION['mensagem_sucesso'] = "Usuário excluído com sucesso!";
        header('Location: index.php?acao=gerenciar_usuarios');
        exit;
    }

    // Mostra página de visualização de logs do sistema.
    public function verLogs() {
        global $pdo;
        $this->verificarAdmin();

        $logModel = new LogModel($pdo);
        $logs = $logModel->buscarTodos();

        require __DIR__ . '/../views/logs_ver.php';
    }
    
}