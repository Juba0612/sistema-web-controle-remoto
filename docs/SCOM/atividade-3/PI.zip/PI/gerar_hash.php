<?php
// Script simples para gerar um hash de senha seguro

$senha_texto_puro = 'admin123';

$hash_gerado = password_hash($senha_texto_puro, PASSWORD_DEFAULT);

echo "<h1>Seu Novo Hash de Senha</h1>";
echo "<p>Use este hash no seu comando SQL UPDATE:</p>";
echo "<hr>";
echo "<p><strong>" . $hash_gerado . "</strong></p>";
echo "<hr>";
echo "<p>Senha original: " . $senha_texto_puro . "</p>";

?>