<?php
session_start();

// Forçar HTTPS
if (empty($_SERVER['HTTPS']) || $_SERVER['HTTPS'] === 'off') {
    // A conexão não é segura
    $location = 'https://' . $_SERVER['HTTP_HOST'] . $_SERVER['REQUEST_URI'];
    header('HTTP/1.1 301 Moved Permanently');
    header('Location: ' . $location);
    exit;
}

// Gerar Token CSRF
if (empty($_SESSION['csrf_token'])) {
    // bin2hex(random_bytes(32)) cria uma string aleatória segura
    $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
}



require_once __DIR__ . '/config/database.php';


$acao = $_GET['acao'] ?? 'login';

// Inclui os controladores necessários
require_once __DIR__ . '/controllers/UsuarioController.php'; // Incluir o novo controller

$usuarioController = new UsuarioController();


switch ($acao) {

    case 'home': // <-- MODIFICADO
    case 'login':
        $usuarioController->mostrarLogin();
        break;

    case 'autenticar':
        $usuarioController->autenticar();
        break;

    case 'dashboard':
        $usuarioController->dashboard();
        break;

    case 'logout':
        $usuarioController->logout();
        break;

    case 'gerenciar_usuarios':
        $usuarioController->gerenciarUsuarios();
        break;
    
    case 'criar_usuario_form':
        $usuarioController->mostrarFormularioUsuario();
        break;

    case 'salvar_usuario':
        $usuarioController->salvarUsuario();
        break;

    case 'editar_usuario_form':
        $usuarioController->mostrarFormularioUsuario();
        break;
    
    case 'atualizar_usuario':
        $usuarioController->atualizarUsuario();
        break;

    case 'excluir_usuario':
        $usuarioController->excluirUsuario();
        break;

    case 'ver_logs':
        $usuarioController->verLogs();
        break;

    default:
        $usuarioController->mostrarLogin();
        break;
}