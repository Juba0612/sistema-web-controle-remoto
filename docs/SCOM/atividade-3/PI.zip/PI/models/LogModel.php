<?php
// Model para gerenciar a tabela 'logs' no banco de dados

class LogModel {

    // A conexão PDO com o banco de dados
   
    private $pdo;

    // Construtor do Model
     
    public function __construct($pdo) {
        $this->pdo = $pdo;
    }

    //Registra uma nova ação no log
     
    public function registrar($id_usuario, $acao) {
        // Se o id_usuario for nulo insere NULL no banco
        $id_usuario = $id_usuario ? $id_usuario : null;

        $sql = "INSERT INTO logs (id_usuario, acao) VALUES (?, ?)";
        $stmt = $this->pdo->prepare($sql);
        
        try {
            $stmt->execute([$id_usuario, $acao]);
        } catch (PDOException $e) {
            error_log("Falha ao registrar log: " . $e->getMessage());
        }
    }

    // Busca todos os logs do sistema e retorna os 200 logs mais recentes primeiro
     
public function buscarTodos() {
        // MODIFICADO: LEFT JOIN com 'users' e seleciona 'users.name'
        $sql = "SELECT 
                    logs.timestamp, 
                    logs.acao, 
                    COALESCE(users.name, 'Sistema/Desconhecido') AS nome_usuario
                FROM logs
                LEFT JOIN users ON logs.id_usuario = users.id
                ORDER BY logs.timestamp DESC
                LIMIT 200";

        $stmt = $this->pdo->query($sql);
        
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }
}