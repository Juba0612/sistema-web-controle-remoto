<?php
// Model para gerenciar a tabela users no banco de dados.

class UsuarioModel {
    
    private $pdo;

    public function __construct($pdo) {
        $this->pdo = $pdo;
    }

    //Verifica as credenciais de login
    public function verificarCredenciais($email, $senha) {
        // Tabela 'users', coluna 'password_hash'
        $stmt = $this->pdo->prepare("SELECT * FROM users WHERE email = ?");
        $stmt->execute([$email]);
        $usuario = $stmt->fetch(PDO::FETCH_ASSOC);

        if ($usuario) {
            // Verifica a senha com 'password_hash'
            if (password_verify($senha, $usuario['password_hash'])) {
                return $usuario;
            }
        }
        return false;
    }

    // Busca todos os usuários
    public function buscarTodosUsuarios() {
        // Tabela 'users', colunas 'id', 'name', 'email', 'user_type'
        $stmt = $this->pdo->query("SELECT id, name, email, user_type FROM users ORDER BY name");
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }

    // Cria um novo usuário no banco de dados
    public function criarUsuario($nome, $email, $perfil, $senha) {
        $senha_hash = password_hash($senha, PASSWORD_DEFAULT);

        try {
            // Tabela 'users', colunas 'name', 'email', 'user_type', 'password_hash'
            $sql = "INSERT INTO users (name, email, user_type, password_hash) VALUES (?, ?, ?, ?)";
            $stmt = $this->pdo->prepare($sql);
            return $stmt->execute([$nome, $email, $perfil, $senha_hash]);
        } catch (PDOException $e) {
            if ($e->getCode() == 23000) {
                return false;
            }
            throw $e;
        }
    }

    // Busca um único usuário pelo seu ID
    public function buscarUsuarioPorId($id) {
        // Tabela 'users', colunas 'id', 'name', 'email', 'user_type'
        $stmt = $this->pdo->prepare("SELECT id, name, email, user_type FROM users WHERE id = ?");
        $stmt->execute([$id]);
        return $stmt->fetch(PDO::FETCH_ASSOC);
    }

    // Atualiza os dados de um usuário 
    public function atualizarUsuario($id, $nome, $email, $perfil) {
        try {
            // Tabela 'users', colunas 'name', 'email', 'user_type'
            $sql = "UPDATE users SET name = ?, email = ?, user_type = ? WHERE id = ?";
            $stmt = $this->pdo->prepare($sql);
            return $stmt->execute([$nome, $email, $perfil, $id]);
        } catch (PDOException $e) {
            if ($e->getCode() == 23000) {
                return false;
            }
            throw $e;
        }
    }

    // Atualiza a senha de um usuário
    public function atualizarSenha($id, $nova_senha) {
        $senha_hash = password_hash($nova_senha, PASSWORD_DEFAULT);
        // Tabela 'users', coluna 'password_hash'
        $sql = "UPDATE users SET password_hash = ? WHERE id = ?";
        $stmt = $this->pdo->prepare($sql);
        return $stmt->execute([$senha_hash, $id]);
    }

    //Exclui um usuário do banco de dados pelo ID
    public function excluirUsuario($id) {
        // Tabela 'users'
        $sql = "DELETE FROM users WHERE id = ?";
        $stmt = $this->pdo->prepare($sql);
        return $stmt->execute([$id]);
    }
}