<?php
// Garantir que apenas usuários logados acessem o dashboard
if (!isset($_SESSION['usuario_id'])) {
    // Se não estiver logado, redireciona para o login
    header('Location: index.php?acao=login');
    exit('Acesso negado.');
}

// Sanitiza o nome do usuário para exibição segura (Proteção XSS)
$nomeUsuario = htmlspecialchars($_SESSION['usuario_nome']);
$perfilUsuario = $_SESSION['usuario_perfil'];
?>

<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Dashboard</title>
    <link rel="stylesheet" href="css/style.css">
    <style>
        /* Estilo adicional para o novo botão */
        .btn-nodered {
            background-color: #8F0000; /* Vermelho do Node-RED */
            color: #fff;
            padding: 15px 20px;
            text-decoration: none;
            border-radius: 5px;
            font-weight: 600;
            display: inline-block;
            margin-top: 15px;
            transition: background-color 0.3s;
        }
        .btn-nodered:hover {
            background-color: #AD0000;
            text-decoration: none;
            transform: scale(1.03);
        }
    </style>
</head>
<body>

    <div class="page-content">

        <div class="nav">
            <span class="nav-brand">Painel de Controle</span>
            <div class="nav-links">
                <a href="index.php?acao=logout">Sair (<?php echo $nomeUsuario; ?>)</a>
            </div>
        </div>

        <h1>Bem-vindo ao Painel</h1>
        <p>Use os links abaixo para gerenciar o sistema ou acessar o controle.</p>
        
        <div class="dashboard-grid">
            
            <div class="dashboard-card">
                <h2>Controle LTR</h2>
                <p>Acesse o painel de controle e visualização dos sensores.</p>
                <!--<a href="https://nodered.org/" target="_blank" class="btn-nodered">-->
                <a href="http://localhost:1880/ui" class="btn-nodered">
                    Acessar Node-RED
                </a>
            </div>

            <?php if ($perfilUsuario == 'admin'): ?>
                <div class="dashboard-card">
                    <h2>Painel de Administrador</h2>
                    <p><a href="index.php?acao=gerenciar_usuarios">Gerenciar Usuários</a></p>
                    <p><a href="index.php?acao=ver_logs">Ver Logs do Sistema</a></p>
                </div>
            <?php endif; ?>
            
        </div>
        
    </div>

</body>
</html>