<?php
// Proteção (Verifica se é admin)
if (!isset($_SESSION['usuario_id']) || $_SESSION['usuario_perfil'] != 'admin') {
    header('Location: index.php?acao=login');
    exit('Acesso negado.');
}
?>
<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Logs do Sistema</title>
    
    <link rel="stylesheet" href="css/style.css">
</head>
<body>

    <div class="page-content">

        <div class="nav">
            <span class="nav-brand">Logs do Sistema</span>
            <div class="nav-links">
                <a href="index.php?acao=dashboard">Voltar ao Dashboard</a> |
                <a href="index.php?acao=logout">Sair</a>
            </div>
        </div>

        <h1>Registros de Atividades</h1>
        <p>Exibindo os 200 registros mais recentes.</p>

        <table>
            <thead>
                <tr>
                    <th>Data e Hora</th>
                    <th>Usuário</th>
                    <th>Ação Realizada</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($logs as $log): ?>
                    <tr>
                        <td><?php echo date('d/m/Y H:i:s', strtotime($log['timestamp'])); ?></td>
                        <td><?php echo htmlspecialchars($log['nome_usuario']); ?></td>
                        <td><?php echo htmlspecialchars($log['acao']); ?></td>
                    </tr>
                <?php endforeach; ?>

                <?php if (empty($logs)): ?>
                    <tr>
                        <td colspan="3">Nenhum log registrado até o momento.</td>
                    </tr>
                <?php endif; ?>
            </tbody>
        </table>

    </div>

</body>
</html>
