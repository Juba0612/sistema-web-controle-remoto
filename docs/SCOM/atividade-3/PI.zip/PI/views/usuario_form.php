<?php
// Proteção
if (!isset($_SESSION['usuario_id']) || $_SESSION['usuario_perfil'] != 'admin') {
    header('Location: index.php?acao=login');
    exit('Acesso negado.');
}

// Lógica para definir se é "Criar" ou "Editar"
$isEdicao = isset($usuario) && $usuario; // $usuario vem do Controller
$tituloPagina = $isEdicao ? "Editar Usuário" : "Adicionar Novo Usuário";
$actionUrl = $isEdicao ? "index.php?acao=atualizar_usuario" : "index.php?acao=salvar_usuario";

// Pré-popular os valores
$nomeVal = $isEdicao ? htmlspecialchars($usuario['name']) : '';
$emailVal = $isEdicao ? htmlspecialchars($usuario['email']) : '';
$perfilVal = $isEdicao ? $usuario['user_type'] : ''; // <-- CORRIGIDO: Erro de sintaxe (/) removido
$idVal = $isEdicao ? $usuario['id'] : '';

// No modo de edição, a senha não é obrigatória
$senhaRequired = $isEdicao ? '' : 'required';

// Limpa o erro da sessão
if (isset($_SESSION['erro_validacao'])) {
    $erro_validacao = $_SESSION['erro_validacao'];
    unset($_SESSION['erro_validacao']);
}
?>

<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo $tituloPagina; ?></title>
    
    <link rel="stylesheet" href="css/style.css">
</head>
<body>

    <div class="page-content">

        <div class="nav">
            <span class="nav-brand"><?php echo $tituloPagina; ?></span>
            <div class="nav-links">
                <a href="index.php?acao=gerenciar_usuarios">Voltar</a> |
                <a href="index.php?acao=logout">Sair</a>
            </div>
        </div>
        
        <div class="form-container">

            <?php if (isset($erro_validacao)): ?>
                <p class="erro"><?php echo $erro_validacao; ?></p>
            <?php endif; ?>

            <form action="<?php echo $actionUrl; ?>" method="POST">
                <input type="hidden" name="csrf_token" value="<?php echo $_SESSION['csrf_token']; ?>">
            
                <?php if ($isEdicao): ?>
                    <input type="hidden" name="id_usuario" value="<?php echo $idVal; ?>">
                <?php endif; ?>

                <div>
                    <label for="nome">Nome:</label><br>
                    <input type="text" id="nome" name="nome" value="<?php echo $nomeVal; ?>" required>
                </div>
                
                <div>
                    <label for="email">Email:</label><br>
                    <input type="email" id="email" name="email" value="<?php echo $emailVal; ?>" required>
                </div>
                
                <div>
                    <label for="perfil">Perfil:</label><br>
                    <select id="perfil" name="perfil" required>
                        <option value="standart" <?php echo ($perfilVal == 'standart') ? 'selected' : ''; ?>>
                            Standart
                        </option>
                        <option value="admin" <?php echo ($perfilVal == 'admin') ? 'selected' : ''; ?>>
                            Administrador
                        </option>
                    </select>
                </div>
                
                <div>
                    <label for="senha">Nova Senha:</label><br>
                    <input type="password" id="senha" name="senha" <?php echo $senhaRequired; ?>>
                    <?php if ($isEdicao): ?>
                        <br><small>Deixe em branco para não alterar a senha.</small>
                    <?php endif; ?>
                </div>
                
                <button type="submit" class="btn">Salvar Usuário</button>
            </form>
            
        </div>
        
    </div>

</body>
</html>