<?php
// Proteção (verifica se é admin)
if (!isset($_SESSION['usuario_id']) || $_SESSION['usuario_perfil'] != 'admin') {
    header('Location: index.php?acao=login');
    exit('Acesso negado.');
}

// Limpa a mensagem da sessão
if (isset($_SESSION['mensagem_sucesso'])) {
    $mensagem_sucesso = $_SESSION['mensagem_sucesso'];
    unset($_SESSION['mensagem_sucesso']);
}
?>
<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Gerenciar Usuários</title>
    
    <link rel="stylesheet" href="css/style.css">
</head>
<body>

    <div class="page-content">

        <div class="nav">
            <span class="nav-brand">Gerenciar Usuários</span>
            <div class="nav-links">
                <a href="index.php?acao=dashboard">Voltar ao Dashboard</a> |
                <a href="index.php?acao=logout">Sair</a>
            </div>
        </div>

        <h1>Usuários Cadastrados</h1>
        
        <a href="index.php?acao=criar_usuario_form" class="btn" style="display: inline-block; margin-bottom: 20px; text-decoration: none; width: auto;">
            Adicionar Novo Usuário
        </a>
        

        <?php if (isset($mensagem_sucesso)): ?>
            <p class="sucesso"><?php echo htmlspecialchars($mensagem_sucesso); ?></p>
        <?php endif; ?>
        <table>
            <thead>
                <tr>
                    <th>Nome</th>
                    <th>Email</th>
                    <th>Perfil</th>
                    <th>Ações</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($usuarios as $usuario): ?>
                    <tr>
                        <td><?php echo htmlspecialchars($usuario['name']); ?></td>
                        <td><?php echo htmlspecialchars($usuario['email']); ?></td>
                        <td><?php echo htmlspecialchars($usuario['user_type']); ?></td>
                        
                        <td>
                            <a href="index.php?acao=editar_usuario_form&id=<?php echo $usuario['id']; ?>">Editar</a> | 
                            
                            <form action="index.php?acao=excluir_usuario" method="POST">
                                <input type="hidden" name="id" value="<?php echo $usuario['id']; ?>">
                                <input type="hidden" name="csrf_token" value="<?php echo $_SESSION['csrf_token']; ?>">
                                <button type="submit" onclick="return confirm('Tem certeza que deseja excluir este usuário?');">
                                   Excluir
                                </button>
                            </form>
                        </td>
                        </tr>
                <?php endforeach; ?>
                
                <?php if (empty($usuarios)): ?>
                    <tr>
                        <td colspan="4">Nenhum usuário cadastrado.</td>
                    </tr>
                <?php endif; ?>
                
            </tbody>
        </table>

    </div>

</body>
</html>